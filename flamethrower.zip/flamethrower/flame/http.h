#ifndef FLAMETHROWER_HTTP_H
#define FLAMETHROWER_HTTP_H

enum class HTTPMethod {
    POST,
    GET,
};

#endif //FLAMETHROWER_HTTP_H