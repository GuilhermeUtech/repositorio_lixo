#define FLAME_VERSION_NUM "0.12.0"
#define FLAME_VERSION "Flamethrower 0.12.0-master"
