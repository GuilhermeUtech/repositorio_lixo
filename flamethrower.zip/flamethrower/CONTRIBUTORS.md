Many thanks to all of flamethrower's contributors (in alphabetical order):

banburybill
elindsey
fcelda
pemensik
supernomad
tomaskrizek
weyrick
yantarou
zach-johnson
